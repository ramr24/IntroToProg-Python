#-----------------------------------------------------------------------------#
#Title: Assignment_06
#Dev: Ramkumar Rajanbabu
#Date: February 12, 2018
#-----------------------------------------------------------------------------#
#---- Data ---#
#textFile = Todo.txt file
#dicRow = Dictionary {Task: Priority}
#listTable = [list] that contains the dictionary
#choice = user inputs number to choose option
#ToDo.loadData() = Method loads data from textFile into a dictionary then inserts dictionary into a list
#ToDo.displayFileData() = Method shows current data in the textFile
#ToDo.displayTableData() = Method shows current data in the listTable
#ToDo.addTask() = Method adds new data to the listTable
#ToDo.removeTask() = Method removes data from listTable
#ToDo.saveData() = Method saves data to the textFile

#--- Input/Output ---#
# User can see a menu with options
# User can see the current data in the textFile
# User can insert or delete data
# User can save to the textFile

#--- Processing ---#
#1) Make a method to load data from textFile to dicRow and listTable
#2) Make a method to display contents
#3) Make a method to add tasks
#4) Make a method to remove tasks
#5) Make a method to save the data
#6) Make class to hold methods
#-----------------------------------------------------------------------------#
#Opens textFile to read
textFile = open("C:\_PythonClass\Assignment_06\Todo.txt", "r")

#Empty dictionary and list to run in for loop
#Choice is blank to use in while loop
dicRow = {}
listTable = []
choice = None

class ToDo(object):
    """A class to hold the methods for the ToDo list program"""

    @staticmethod
    def loadData():
        """For loop loads data from textFile into a dictionary then inserts dictionary into a list"""
        for line in textFile:
            rdText = line.split(",")
            dicRow = {"Task":rdText[0].strip(), "Priority":rdText[1].strip()}
            listTable.append(dicRow)
        textFile.close()

    @staticmethod
    def displayFileData():
        """Shows current data in the textFile"""
        print("Current Data in ToDo:")
        for row in listTable:
            print(row["Task"] + " = " + row["Priority"] + " priority")
        print()

    @staticmethod
    def displayTableData():
        """Shows current data in the listTable"""
        print("Current Data in Table:")
        for dicRow in listTable:
            print(dicRow)
        print()

    @staticmethod
    def addTask():
        """Adds new data to the listTable"""
        task = input("Enter the task: ").strip()
        prior = input("Enter the level of priority: ").strip()
        dicRow = {"Task": task, "Priority": prior}
        listTable.append(dicRow)
        print()
        ToDo.displayTableData()
        ToDo.displayFileData()

    @staticmethod
    def removeTask():
        """Removes data from listTable"""
        remTask = input("Enter the task to remove: ")
        blnItem = False
        rowNumber = 0
        while(rowNumber < len(listTable)):
            if(remTask == str(list(dict(listTable[rowNumber]).values())[0])):
                del listTable[rowNumber]
                blnItem = True
            rowNumber += 1
        if(blnItem == True):
            print("The task was removed." + "\n")
        else:
            print("Sorry, that task is not found!" + "\n")
        ToDo.displayFileData()

    @staticmethod
    def saveData():
        """Saves data to the textFile"""
        ToDo.displayFileData()
        save = input("Would you like to the save your data? (y/n): ").strip()
        if(save.lower() == "y"):
            textFile = open("C:\_PythonClass\Assignment_06\Todo.txt", "w")
            for dicRow in listTable:
                textFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            textFile.close()
            print()
            print("The data was saved to the file!")
            ToDo.displayFileData()
        else:
            print("The data was not saved to file!" + "\n")

ToDo.loadData()
#While loop breaks when user chooses choice == 5
while choice != "5":
    #Menu of Options is presented to the user
    print("Menu of Options")
    print("1) Show current data")
    print("2) Add a new item")
    print("3) Remove an existing item")
    print("4) Save Data to File")
    print("5) Exit Program" + "\n")

    choice = input("Enter a number to choose your option (1-5): ")
    print()
    #User is shown current data in the textFile
    if(choice.strip() == "1"):
        ToDo.displayFileData()

    #User adds new data to the listTable
    elif(choice.strip() == "2"):
        ToDo.addTask()

    #User removes data from listTable
    elif(choice == "3"):
        ToDo.removeTask()

    #Saves data from listTable to textFile
    elif(choice == "4"):
        ToDo.saveData()

    #User exits the program
    elif(choice == "5"):
        print("You have exited the program!")
    else:
        print("Sorry, but that option is not available. Please choose from options 1-5." + "\n")