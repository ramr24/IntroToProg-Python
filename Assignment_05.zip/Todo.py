#-----------------------------------------------------------------------------#
#Title: Assignment_05
#Dev: Ramkumar Rajanbabu
#Date: February 12, 2018
#-----------------------------------------------------------------------------#
#---- Data ---#
#textFile = Todo.txt file
#dicRow = Dictionary {Task: Priority}
#listTable = [list] that contains the dictionary
#choice = user inputs number to choose option

#--- Input/Output ---#
# User can see a menu with options
# User can see the current data in the textFile
# User can insert or delete data
# User can save to the textFile

#--- Processing ---#
# Step 1: Load the current data in a text file called ToDo.txt into a Dictionary.
# Step 2: Display a menu of choices to the user
# Step 3: Display all todo items to user
# Step 4: Add a new item to the list/Table
# Step 5: Remove a new item to the list/Table
# Step 6: Save tasks to the ToDo.txt file
# Step 7: Exit the program
#-----------------------------------------------------------------------------#
#Opens textFile to read
textFile = open("C:\_PythonClass\Assignment_05\Todo.txt", "r")

#Empty dictionary and list to run in for loop
#Choice is blank to use in while loop
dicRow = {}
listTable = []
choice = None

#For loop loads data from textFile into a dictionary then inserts dictionary into a list
for line in textFile:
    rdText = line.split(",")
    dicRow = {"Task":rdText[0].strip(), "Priority":rdText[1].strip()}
    listTable.append(dicRow)
textFile.close()

#While loop breaks when user chooses choice == 5
while choice != "5":
    #Menu of Options is presented to the user
    print("Menu of Options")
    print("1) Show current data")
    print("2) Add a new item")
    print("3) Remove an existing item")
    print("4) Save Data to File")
    print("5) Exit Program" + "\n")

    #User enters their choice for their option
    choice = input("Enter a number to choose your option (1-5): ")
    print()
    #User is shown current data in the textFile
    if(choice.strip() == "1"):
        print("Current Data in ToDo:")
        for row in listTable:
            print(row["Task"] + " = " + row["Priority"] + " priority")
        print()

    #User adds new data to the listTable
    elif(choice.strip() == "2"):
        task = input("Enter the task: ").strip()
        prior = input("Enter the level of priority: ").strip()
        dicRow = {"Task":task, "Priority":prior}
        listTable.append(dicRow)
        print()
        #Shows current data in the listTable
        print("Current Data in Table:")
        for dicRow in listTable:
            print(dicRow)
        print()
        #Show current data in the textFile
        print("Current Data in ToDo:")
        for row in listTable:
            print(row["Task"] + " = " + row["Priority"] + " priority")
        print()

    #User removes data from listTable
    elif(choice == "3"):
        delTask = input("Enter the task to remove: ")
        #Not able to figure out how to delete a task
        if(delTask in listTable):
            print(delTask)
            print("The task was removed." + "\n")
        else:
            print("Sorry, that task is not found!" + "\n")
        #Show current data in the textFile
        print("Current Data in ToDo:")
        for row in listTable:
            print(row["Task"] + " = " + row["Priority"] + " priority")
        print()

    #Saves data from listTable to textFile
    elif(choice == "4"):
        #Show current data in the textFile
        print("Current Data in ToDo:")
        for row in listTable:
            print(row["Task"] + " = " + row["Priority"] + " priority")
        print()
        #Saves data to textFile
        save = input("Would you like to the save your data? (y/n): ").strip()
        if (save.lower() == "y"):
            textFile = open("C:\_PythonClass\Assignment_05\Todo.txt", "w")
            #For loop to write data from listTable into textFile
            for dicRow in listTable:
                textFile.write(dicRow["Task"] + "," + dicRow["Priority"] + "\n")
            textFile.close()
            print()
            print("The data was saved to the file!")
            print("Saved data:")
            #Show current data in the textFile
            for row in listTable:
                print(row["Task"] + " = " + row["Priority"] + " priority")
            print()
        else:
            print("The data was not saved to file!" + "\n")

    #User exits the program
    elif(choice == "5"):
        print("You have exited the program!")
    else:
        print("Sorry, but that option is not available. Please choose from options 1-5." + "\n")